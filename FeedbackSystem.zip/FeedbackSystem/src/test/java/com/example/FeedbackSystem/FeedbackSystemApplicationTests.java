package com.example.FeedbackSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
